$(document).ready(async function() {
    //fetchInstructors();
    //fetchCourses();
    // Fetch instructors and courses when the page loads
    //alert("Courses are being loaded");
    try {
    const instructors = await fetchInstructors();
    const courses = await fetchCourses();
    //alert("Courses have loaded");
    //alert(courses);
    /*const courses = [
        { id: 101, name: "Software Engineering", instructor: "Dr. Smith", section: "CS-A", color: "#FFD700", department: "Computer Science" },
        { id: 102, name: "Information Security", instructor: "Dr. Johnson", section: "CS-B", color: "#7FFFD4", department: "Computer Science" },
        { id: 103, name: "DevOps", instructor: "Dr. Williams", section: "CS-C", color: "#4456D4", department: "Computer Science" },
        { id: 104, name: "Principles of Programming Languages", instructor: "Dr. Brown", section: "CS-D", color: "#3FAFD4", department: "Computer Science" },
        { id: 105, name: "System Modeling & Design", instructor: "Dr. Jones", section: "CS-E", color: "#9CBFD4", department: "Computer Science" },
        { id: 106, name: "Computer Graphics", instructor: "Dr. Taylor", section: "CS-F", color: "#FF8C00", department: "Computer Science" },
        { id: 107, name: "Artificial Intelligence", instructor: "Dr. Lee", section: "CS-G", color: "#6B8E23", department: "Computer Science" },
        { id: 108, name: "Database Systems", instructor: "Dr. Walker", section: "CS-H", color: "#4682B4", department: "Computer Science" },
        { id: 109, name: "Network Security", instructor: "Dr. Hall", section: "CS-I", color: "#D2691E", department: "Computer Science" },
        { id: 110, name: "Machine Learning", instructor: "Dr. Young", section: "CS-J", color: "#2E8B57", department: "Computer Science" },
        { id: 111, name: "Data Structures", instructor: "Dr. Hernandez", section: "CS-K", color: "#C71585", department: "Computer Science" },
        { id: 112, name: "Algorithm Analysis", instructor: "Dr. King", section: "CS-L", color: "#FF4500", department: "Computer Science" },
        { id: 113, name: "Operating Systems", instructor: "Dr. Wright", section: "CS-M", color: "#7B68EE", department: "Computer Science" },
        { id: 114, name: "Human-Computer Interaction", instructor: "Dr. Lopez", section: "CS-N", color: "#DA70D6", department: "Computer Science" },
        { id: 115, name: "Web Development", instructor: "Dr. Hill", section: "CS-O", color: "#8FBC8F", department: "Computer Science" },
        { id: 116, name: "Mobile App Development", instructor: "Dr. Scott", section: "CS-P", color: "#4169E1", department: "Computer Science" },
        { id: 117, name: "Cloud Computing", instructor: "Dr. Green", section: "CS-Q", color: "#FA8072", department: "Computer Science" },
        { id: 118, name: "Cybersecurity Fundamentals", instructor: "Dr. Adams", section: "CS-R", color: "#98FB98", department: "Computer Science" },
        { id: 119, name: "Quantum Computing", instructor: "Dr. Baker", section: "CS-S", color: "#DDA0DD", department: "Computer Science" },
        { id: 120, name: "Virtual Reality", instructor: "Dr. Gonzalez", section: "CS-T", color: "#00CED1", department: "Computer Science" }
        // Add more courses as needed
    ];*/
    
    courses.forEach(course => {

        let color = "";
	if (course.department_id == 1) {
		color = `#FF${course.semester}000`; // Example color for department_id 1
	    } else if (course.department_id == 2) {
		color = `#EE${course.semester}000`; // Example color for department_id 2
	    } else if (course.department_id == 3) {
		color = `#CC${course.semester}000`; // Example color for department_id 3
	    } else if (course.department_id == 4) {
		color = `#BB${course.semester}000`; // Example color for department_id 4
	    } else if (course.department_id == 5) {
		color = `#AA${course.semester}000`; // Example color for department_id 5
	    }
		$('#coursesList').append(`<div class="course" data-id="${course.id}" data-name="${course.name}" data-section="${course.section}" data-semester="${course.semester}" data-instructor_id="${course.instructor_id}" data-department_id="${course.department_id}" style="background-color: ${color};">${course.name} ${course.section} semester ${course.semester}</div>`);
    });
    //
    $('.course').draggable({
        helper: 'clone',
        revert: "invalid"
    });
    $('.course').on('click', function() {
        const courseId = $(this).data('id');
        const name = $(this).data('name');
        const section = $(this).data('section');
        const departmentId = $(this).data('department_id');
        const instructorId = $(this).data('instructor_id');
        let instructorname="";
        instructors.forEach(course => {
            if(course.id==instructorId){
                instructorname=course.name;
            }
        });

        
        // Redirect to the course details page with necessary parameters
        window.location.href = `courseDetails.html?courseId=${courseId}&name=${name}&section=${section}&departmentId=${departmentId}&instructorId=${instructorId}&instructorname=${instructorname}`;
     });
    instructors.forEach(course => {
        let color = "";
        if (course.department_id == 1) {
            color = `#FF${course.semester}000`; // Example color for department_id 1
            } else if (course.department_id == 2) {
            color = `#EE${course.semester}000`; // Example color for department_id 2
            } else if (course.department_id == 3) {
            color = `#CC${course.semester}000`; // Example color for department_id 3
            } else if (course.department_id == 4) {
            color = `#BB${course.semester}000`; // Example color for department_id 4
            } else if (course.department_id == 5) {
            color = `#AA${course.semester}000`; // Example color for department_id 5
            }
        $('#instructorsList').append(`<div class="instructor" data-id="${course.id}" data-name="${course.name}" style="background-color: ${color};">${course.name}</div>`);
    }   );

    $('.instructor').draggable({
        helper: 'clone',
        revert: "invalid"
    });

    courses.forEach(course => {
        let color = "";
        if (course.department_id == 1) {
            color = `#FF${course.semester}000`; // Example color for department_id 1
            } else if (course.department_id == 2) {
            color = `#EE${course.semester}000`; // Example color for department_id 2
            } else if (course.department_id == 3) {
            color = `#CC${course.semester}000`; // Example color for department_id 3
            } else if (course.department_id == 4) {
            color = `#BB${course.semester}000`; // Example color for department_id 4
            } else if (course.department_id == 5) {
            color = `#AA${course.semester}000`; // Example color for department_id 5
            }
        $('#sectionsList').append(`<div class="section" data-id="${course.id}" data-name="${course.section}" style="background-color: ${color};">${course.section}</div>`);
    }
    );

    $('.section').draggable({
        helper: 'clone',
        revert: "invalid"
    });

    
        $('#generateTimetable').click(function() {
            const totalRooms = parseInt($('#totalRooms').val()) || 0;
            const classDuration = parseInt($('#classDuration').val()) || 0;
            const breakTime = parseInt($('#breakTime').val()) || 0;
            const totalDays = Math.min(parseInt($('#totalDays').val()) || 0, 7);
            const startTime = $('#startTime').val();
            const endTime = $('#endTime').val();
            generateTimetable(totalRooms, classDuration, breakTime, totalDays, startTime, endTime);

        });
    }catch (error) {
        console.error('Error:', error);
        // Handle the error appropriately
    }
    
});
// Function to fetch data from the server
/*async function fetchData(endpoint) {
  try {
    alert('SUKAAA');
    const response = await fetch(`http://localhost:3000/${endpoint}`);
    const data = await response.json();
    return data;
  } catch (error) {
  	alert('BLYAAAAA');
    console.error('Error fetching data:', error);
    throw error;
  }
}*/
// Function to fetch courses from the server
 function fetchInstructors() {
    return new Promise((resolve, reject) => {
        $.get('http://localhost:3000/instructors')
            .done(data => {
            	//alert("SUKASUKA");
                console.log('Fetched instructors:', data);
                //renderCourses(data);
                resolve(data);
            })
            .fail(error => {
            	alert("BLYAABLYAA");
                console.error('Error fetching instructors:', error);
                reject(error);
            });
    });
}



  
  // Function to fetch courses from the server
function fetchCourses() {
    return new Promise((resolve, reject) => {
        $.get('http://localhost:3000/courses')
            .done(data => {
            	//alert("SUKA");
                console.log('Fetched courses:', data);
                //renderCourses(data);
                resolve(data);
            })
            .fail(error => {
            	alert("BLYAA");
                console.error('Error fetching courses:', error);
                reject(error);
            });
    });
}

  

// Function to render courses in HTML
/*function renderCourses(courses) {
    const coursesList = $('#coursesList');
    coursesList.empty(); // Clear the existing content

    courses.forEach((course) => {
        let color = "";
        if (course.department_id == 1) {
            // Set color based on department_id
            color = "#FF" + toString(course.semester) + "000"; // Example color for department_id 1
        } else if (course.department_id == 2) {
            // Set color based on department_id
            color = "#EE" + toString(course.semester) + "000"; // Example color for department_id 1
        } else if (course.department_id == 3) {
            // Set color based on department_id
            color = "#CC" + toString(course.semester) + "000"; // Example color for department_id 1
        } else if (course.department_id == 4) {
            // Set color based on department_id
            color = "#BB" + toString(course.semester) + "000"; // Example color for department_id 1
        } else if (course.department_id == 5) {
            // Set color based on department_id
            color = "#AA" + toString(course.semester) + "000"; // Example color for department_id 1
        }
        coursesList.append(`<div class="course" data-id="${course.id}" style="background-color: ${color};">${course.name}</div>`);
    });

    // Make the courses draggable
    $('.course').draggable({
        helper: 'clone',
        revert: 'invalid',
    });
}*/
function generateTimetable(totalRooms, classDuration, breakTime, totalDays, startTime, endTime) {
    let timetableHtml = '<div class="day-tabs">';
    const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    for (let day = 0; day < totalDays; day++) {
        timetableHtml += `<span class="day-tab" onclick="switchDay(${day + 1})">${weekdays[day]}</span>`;
    }
    timetableHtml += '</div><div class="timetable-day">';

    for (let day = 1; day <= totalDays; day++) {
        timetableHtml += `<table class="timetable" id="day${day}"><tr><th>Room / Time</th>`;
        let currentHour = parseInt(startTime.split(':')[0]);
        let currentMinute = parseInt(startTime.split(':')[1]);
        const endHour = parseInt(endTime.split(':')[0]);
        const endMinute = parseInt(endTime.split(':')[1]);

        // Headers for class and break times
        
        while (true) {
            let slotEnd = addMinutes(currentHour, currentMinute, classDuration);

            // Check if adding the next class slot would exceed the end time
            if (slotEnd.hour > endHour || (slotEnd.hour === endHour && slotEnd.minute >= endMinute)) {
                break;
            }
            timetableHtml += `<th>${formatTime(currentHour, currentMinute)}-${formatTime(slotEnd.hour, slotEnd.minute)}</th>`;

            // Move current time to the end of the class slot
            currentHour = slotEnd.hour;
            currentMinute = slotEnd.minute;

            let breakEnd = addMinutes(currentHour, currentMinute, breakTime);
            // Check if adding the next break would exceed the end time
            if (breakEnd.hour > endHour || (breakEnd.hour === endHour && breakEnd.minute >= endMinute)) {
                break;
            }
            timetableHtml += `<th class="break-time">${formatTime(currentHour, currentMinute)}-${formatTime(breakEnd.hour, breakEnd.minute)}</th>`;

            // Move current time to the end of the break
            currentHour = breakEnd.hour;
            currentMinute = breakEnd.minute;
        }

        timetableHtml += '</tr>';

        // Rows for class and break times
        for (let room = 1; room <= totalRooms; room++) {
            timetableHtml += `<tr><td>Room ${room}</td>`;
            currentHour = parseInt(startTime.split(':')[0]);
            currentMinute = parseInt(startTime.split(':')[1]);
        
            while (true) {
                let slotEnd = addMinutes(currentHour, currentMinute, classDuration);
        
                // Check if adding the next class slot would exceed the end time
                if (slotEnd.hour > endHour || (slotEnd.hour === endHour && slotEnd.minute >= endMinute)) {
                    break;
                }
                timetableHtml += `<td class="time-slot" data-time="${formatTime(currentHour, currentMinute)}-${formatTime(slotEnd.hour, slotEnd.minute)}"></td>`;
                
                currentHour = slotEnd.hour;
                currentMinute = slotEnd.minute;
        
                let breakEnd = addMinutes(currentHour, currentMinute, breakTime);
        
                // Check if adding the next break would exceed the end time
                if (breakEnd.hour > endHour || (breakEnd.hour === endHour && breakEnd.minute >= endMinute)) {
                    // Do not add a break slot if it exceeds end time
                    break;
                }
                timetableHtml += `<td class="break-time-slot" style="background-color: #cccccc;"></td>`;
        
                currentHour = breakEnd.hour;
                currentMinute = breakEnd.minute;

            }
            timetableHtml += '</tr>';
        }
        
        timetableHtml += '</table>';
        
        // add default courses to timetable (for testing)
$('#day1 .time-slot[data-time="09:00 AM-10:00 AM"]').append('<div class="dropped-course" data-id="101" style="background-color: #FFD700;">Software Engineering</div>');  
$('#day1 .time-slot[data-time="10:00 AM-11:00 AM"]').append('<div class="dropped-course" data-id="102" style="background-color: #7FFFD4;">Information Security</div>');
$('#day1 .time-slot[data-time="11:00 AM-12:00 PM"]').append('<div class="dropped-course" data-id="103" style="background-color: #4456D4;">DevOps</div>');
$('#day1 .time-slot[data-time="12:00 PM-01:00 PM"]').append('<div class="dropped-course" data-id="104" style="background-color: #3FAFD4;">Principles of Programming Languages</div>');

    }

    $('#timetableContainer').html(timetableHtml);
    setupDroppables();
    switchDay(1);
}

function setupDroppables() {
    $('.timetable .time-slot').not('.break-time').droppable({
        accept: ".course, .dropped-course",
        drop: function (event, ui) {
            const courseId = $(ui.draggable).data('id');
            const courseName = $(ui.draggable).data('name') || $(ui.draggable).text();
            const courseColor = $(ui.draggable).css('background-color');
            const departmentId = $(ui.draggable).data('department_id');
            const semesterNo = $(ui.draggable).data('semester');
            const section= $(ui.draggable).data('section');
            const instructorId = $(ui.draggable).data('instructor_id');
            //alert(instructorId);
            const timeSlot = $(this).data('time');
            const dayId = $(this).closest('.timetable').attr('id');
            const isClone = $(ui.draggable).hasClass('course');

            const roomOccupiedInSlot = $(this).find('.dropped-course').length > 0;
            
            if (isClone) {
                if (roomOccupiedInSlot || isCourseScheduled(courseId, timeSlot, dayId)) {
                    alert(`Clash detected: ${courseName} cannot be added to an occupied time slot or room.`);
                    return;
                }
                if (roomOccupiedInSlot || isInstructorCourseScheduled(instructorId, timeSlot, dayId)){
                    alert(`Clash detected with another lecture class: ${courseName} cannot be added to an occupied time slot or room where there is already class scheduled.`);
                    return;
                }
                if (roomOccupiedInSlot || isSectionScheduled(semesterNo , section , departmentId, timeSlot, dayId)){
                    alert(`Clash detected with another lecture class of same section : ${courseName} cannot be added to an occupied time slot or room where there is already class scheduled of the same section.`);
                    return;
                }
                $(this).append(`<div class="dropped-course" data-id="${courseId}" data-department_id="${departmentId}" data-semester="${semesterNo}" data-instructor_id="${instructorId}" data-section="${section}" style="background-color: ${courseColor};">${courseName} ${section} ${semesterNo}</div>`);
            } else {
                const currentSlot = $(ui.draggable).parent();
                if (this !== currentSlot[0] && !isCourseScheduled(courseId, timeSlot, dayId)) {
                    $(this).append(ui.draggable);
                } else {
                    alert(`Clash detected: Cannot move ${courseName} to an occupied time slot.`);
                }
            }

            $(this).find('.dropped-course').last().draggable({
                helper: 'clone',
                revert: "invalid",
                start: function() {
                    const courseId = $(this).data('id');
                    const section = $(this).data('section');
                    //displayCourseDetails(courseId, section);
                },
                click: function() {
                    const courseId = $(this).data('id');
                    const section = $(this).data('section');
                    //displayCourseDetails(courseId);
                }
                
            });
            $('.dropped-course').on('click', function() {
                const courseId = $(this).data('id');
                const section = $(this).data('section');
                const departmentId = $(this).data('department_id');
                
                // Redirect to the course details page with necessary parameters
                window.location.href = `courseDetails.html?courseId=${courseId}&section=${section}&departmentId=${departmentId}`;
             });
             
        }
    });

    $('#coursesList').droppable({
        accept: ".dropped-course",
        drop: function (event, ui) {
            ui.draggable.remove();
        }
    });
}


function addMinutes(hour, minute, minsToAdd) {
    minute += minsToAdd;
    hour += Math.floor(minute / 60);
    minute %= 60;
    return { hour, minute };
}

function formatTime(hour, minute) {
    let period = "AM";
    if (hour >= 12) {
        period = "PM";
        if (hour > 12) hour -= 12;
    }
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} ${period}`;
}

function switchDay(day) {
    $('.timetable').hide();
    $(`#day${day}`).show();
}

function isCourseScheduled(courseId, timeSlot, dayId) {
    let isScheduled = false;
    $(`#${dayId} .time-slot[data-time="${timeSlot}"]`).each(function() {
        if ($(this).find(`.dropped-course[data-id="${courseId}"]`).length > 0) {
            isScheduled = true;
            return false; // Break the loop
        }
    });
    return isScheduled;
}

function isInstructorCourseScheduled(instructorId, timeSlot, dayId) {
    let isScheduled = false;
    $(`#${dayId} .time-slot[data-time="${timeSlot}"]`).each(function() {
        if ($(this).find(`.dropped-course[data-instructor_id="${instructorId}"]`).length > 0) {
            isScheduled = true;
            return false; // Break the loop
        }
    });
    return isScheduled;
}

function isSectionScheduled(SemesterNo , Section , DepartmentId, timeSlot, dayId) {
    let isScheduled = false;
    $(`#${dayId} .time-slot[data-time="${timeSlot}"]`).each(function() {
        if ($(this).find(`.dropped-course[data-semester="${SemesterNo}"]`).length > 0 &&
        $(this).find(`.dropped-course[data-section="${Section}"]`).length > 0 &&
        $(this).find(`.dropped-course[data-department_id="${DepartmentId}"]`).length > 0) {
            isScheduled = true;
            return false; // Break the loop
        }
    });
    return isScheduled;
}



