#include <iostream>

using namespace std;

int main() {
  int temperature;

  cout << "Enter the temperature in Centigrade: ";
  cin >> temperature;

  switch (temperature) {
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
          cout << "Very Hot" << endl;
          break;
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
          cout << "Hot" << endl;
          break;
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
          cout << "Normal" << endl;
          break;
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
          cout << "Cold" << endl;
          break;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
          cout << "Very Cold" << endl;
          break;
      default:
          cout << "Invalid Temperature" << endl;
          break;
  }

  return 0;
}