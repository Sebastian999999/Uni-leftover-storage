const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();
const port = 3000;

// Enable CORS for all routes
app.use(cors());
// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'PokemonDestroyer10000',
    database: 'TimeTable',
});

// Connect to MySQL
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
    } else {
        console.log('Connected to MySQL database');
    }
});
app.get('/', (req, res) => {
    res.send('Hello, this is your Express.js server!');
  });
// Define routes
app.get('/courses', (req, res) => {
    connection.query('SELECT * FROM courses', (error, results) => {
        if (error) {
            console.error('Error fetching courses:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            console.log("COurses fetched successfully");
            //console.log(results);
            res.json(results);
        }
    });
});

app.get('/instructors', (req, res) => {
    connection.query('SELECT * FROM instructors', (error, results) => {
        if (error) {
            console.error('Error fetching instructors:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            res.json(results);
        }
    });
});

// Add more routes for other data as needed...

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
