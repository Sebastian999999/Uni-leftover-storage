#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Error: Exactly one argument (file) is required for deletion."
    exit 1
fi

recycle_bin="recycle_bin"
mkdir -p "$recycle_bin"

chmod +w "$recycle_bin"

target_file="$1"

if [ ! -e "$target_file" ]; then
    echo "Error: The file '$target_file' does not exist."
    exit 1
fi

cp "$target_file" "$recycle_bin/"

rm -f "$target_file"

echo "The file '$target_file' has been moved to '$recycle_bin/' and deleted from the current directory."