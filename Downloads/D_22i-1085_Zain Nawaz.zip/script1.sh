proc_count=$(grep -c '^processor' /proc/cpuinfo)
core_count=$(grep 'core id' /proc/cpuinfo | sort -u | wc -l)

sibling_count=$(grep 'siblings' /proc/cpuinfo | head -n 1 | awk '{print $3}')
cpu_cores=$(grep 'cpu cores' /proc/cpuinfo | head -n 1 | awk '{print $4}')

if [ $sibling_count -eq $cpu_cores ]; then
    ht_status="No"
else
    ht_status="Yes"
fi

if [ $ht_status == "Yes" ]; then
    total_cores_ht=$(grep 'core id' /proc/cpuinfo | wc -l)
else
    total_cores_ht=$core_count
fi

cpu_model=$(grep 'model name' /proc/cpuinfo | head -n 1 | cut -d: -f2 | sed -e 's/^[ \t]*//')

echo "Total Processors: $proc_count"
echo "Total Physical Cores: $core_count"
echo "Hyperthreading Enabled: $ht_status"
echo "Total Cores with Hyperthreading: $total_cores_ht"
echo "CPU Model: $cpu_model"

output_file="cpu_details.txt"

echo "Total Processors: $proc_count" > "$output_file"
echo "Total Physical Cores: $core_count" >> "$output_file"
echo "Hyperthreading Enabled: $ht_status" >> "$output_file"
echo "Total Cores with Hyperthreading: $total_cores_ht" >> "$output_file"
echo "CPU Model: $cpu_model" >> "$output_file"