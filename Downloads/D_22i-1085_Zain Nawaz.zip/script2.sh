#!/bin/bash

echo "Input the quantity of files to generate: "
read num_files

mkdir -p SampleData

for ((index=1; index<=num_files; index++)); do
    file_name="sample_${index}"

    random_content=$(base64 /dev/urandom | head -c 1000)

    echo "$random_content" > "SampleData/$file_name"

    echo "Generated $file_name with random text."
done