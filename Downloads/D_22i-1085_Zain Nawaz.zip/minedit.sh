#!/bin/bash

generate_new_c_file() {
    echo "Generating a new C file..."
    read -p "Provide the filename (excluding extension): " new_file
    if [ -z "$new_file" ]; then
        echo "Error: Filename is required."
        return 1
    fi
    touch "$new_file.c"
    echo "New file '$new_file.c' has been created."
}

modify_existing_c_file() {
    read -p "Provide the filename to modify: " modify_file
    if [ ! -f "$modify_file.c" ]; then
        echo "Error: '$modify_file.c' does not exist."
        return 1
    fi
    echo "Opening '$modify_file.c' for modification..."
    nano "$modify_file.c"
}

build_c_file() {
    read -p "Provide the filename to build (excluding extension): " build_file
    if [ ! -f "$build_file.c" ]; then
        echo "Error: '$build_file.c' does not exist."
        return 1
    fi
    echo "Building '$build_file.c'..."
    gcc -o "$build_file" "$build_file.c"
    if [ $? -ne 0 ]; then
        echo "Error: Build failed."
        return 1
    fi
    echo "'$build_file' has been built successfully."
}

preserve_changes_in_file() {
    read -p "Provide the filename to preserve changes (excluding extension): " preserve_file
    if [ ! -f "$preserve_file.c" ]; then
        echo "Error: '$preserve_file.c' does not exist."
        return 1
    fi
    mv "$preserve_file.c" "backup_$preserve_file.c"
    echo "Backup of '$preserve_file.c' has been created as 'backup_$preserve_file.c'."
}

execute_c_file() {
    read -p "Provide the filename to execute (excluding extension): " execute_file
    if [ ! -f "$execute_file.c" ]; then
        echo "Error: '$execute_file.c' does not exist."
        return 1
    fi
    echo "Executing '$execute_file.c'..."
    ./"$execute_file"
    echo "'$execute_file' has been executed successfully."
}

display_menu() {
    while true; do
        echo "Options:"
        echo "1. Generate a new C file"
        echo "2. Modify an existing C file"
        echo "3. Build a C file"
        echo "4. Preserve changes in a C file"
        echo "5. Execute a C file"
        echo "0. Quit"
        read -p "Select an option (0-5): " menu_option
        case $menu_option in
            0)
                echo "Quitting..."
                exit ;;
            1)
                generate_new_c_file ;;
            2)
                modify_existing_c_file ;;
            3)
                build_c_file ;;
            4)
                preserve_changes_in_file ;;
            5)
                execute_c_file ;;
            *)
                echo "Invalid option. Please select a number between 0 and 5." ;;
        esac
    done
}

display_menu