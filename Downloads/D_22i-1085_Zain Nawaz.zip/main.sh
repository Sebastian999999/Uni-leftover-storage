while true
do
    echo "Options:"
    echo "1. Fetch CPU Info"
    echo "2. Generate Test Directory"
    echo "3. Safe File Deletion"
    echo "4. MinEdit: CLI C Program Editor"
    echo "5. Terminate"

    read -p "Choose an option: " option

    case $option in
        1) ./script1.sh ;;
        2) ./script2.sh ;;
        3) 
            echo "Input file to delete"
            read file
            ./script3.sh "$file"
            ;;
        4) ./minedit.sh ;;
        5) 
            echo "Ending Menu Script."
            exit 0
            ;;
        *) echo "Invalid option. Please select a valid one (1-5)." ;;
    esac
done